import argparse
import subprocess
import os

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-json', '--answers_json_path', type=str, required=True,
                        help='Path to the JSONL file used in all summary scripts')
    args = parser.parse_args()

    # 実行対象のスクリプト（summary_until.pyは除外）
    scripts = [
        "defect_summary.py",
        "product_summary.py",
        "summary.py"
    ]

    for script in scripts:
        script_path = os.path.join("helper", script)
        print(f"Executing: {script_path} --answers_json_path {args.answers_json_path}")
        subprocess.run(["python", script_path, "--answers_json_path", args.answers_json_path], check=True)

if __name__ == "__main__":
    main()
